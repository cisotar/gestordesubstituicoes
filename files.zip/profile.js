/**
 * profile.js — Modal de perfil do professor logado.
 *
 * O professor pode editar:
 *   - Nome
 *   - WhatsApp e celular
 *   - E-mail de contato (diferente do e-mail de login)
 *
 * O admin pode acessar o perfil de qualquer professor via tabTeachers.
 * O professor só acessa o próprio perfil (identificado pelo e-mail de login).
 */

import { state, saveState }  from './state.js';
import { h }                  from './helpers.js';
import { saveDoc }            from './db.js';
import { renderSettings }     from './render.js';

function show(html) {
  document.getElementById('modal-body').innerHTML = html;
  document.getElementById('overlay').classList.add('on');
}

function close() {
  document.getElementById('overlay').classList.remove('on');
}

/**
 * Abre o modal de perfil para um professor.
 * @param {object} teacher — objeto do state.teachers
 */
export function renderProfileModal(teacher) {
  if (!teacher) {
    show(`
      <div class="m-hdr">
        <h3 style="font-size:17px">Meu Perfil</h3>
        <button class="m-close" onclick="document.getElementById('overlay').classList.remove('on')">×</button>
      </div>
      <div style="text-align:center;padding:24px;color:var(--t2)">
        <p>Perfil não encontrado.</p>
        <p style="font-size:13px;margin-top:8px">
          Seu cadastro pode estar pendente de aprovação pelo administrador.
        </p>
      </div>`);
    return;
  }

  show(`
    <div class="m-hdr">
      <h3 style="font-size:17px">Meu Perfil</h3>
      <button class="m-close" onclick="document.getElementById('overlay').classList.remove('on')">×</button>
    </div>

    <div style="display:flex;align-items:center;gap:12px;padding:14px;border-radius:var(--r);
      background:var(--surf2);margin-bottom:20px">
      <div style="width:44px;height:44px;border-radius:50%;background:var(--bdr2);
        display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;
        color:var(--t2);flex-shrink:0">
        ${h(teacher.name?.charAt(0) ?? '?')}
      </div>
      <div>
        <div style="font-weight:700;font-size:15px">${h(teacher.name)}</div>
        <div style="font-size:12px;color:var(--t2)">${h(teacher.email)}</div>
      </div>
    </div>

    <div style="display:flex;flex-direction:column;gap:14px;margin-bottom:20px">
      <div class="fld">
        <label class="lbl">Nome exibido</label>
        <input class="inp" id="prof-name" value="${h(teacher.name ?? '')}"
          placeholder="Nome completo">
      </div>

      <div class="divider"></div>
      <div style="font-size:11px;font-weight:700;color:var(--t3);
        text-transform:uppercase;letter-spacing:.06em">Contato</div>

      <div class="fld">
        <label class="lbl">E-mail de contato</label>
        <input class="inp" id="prof-email" type="email"
          value="${h(teacher.email ?? '')}"
          placeholder="professor@escola.edu.br">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div class="fld">
          <label class="lbl">WhatsApp</label>
          <input class="inp" id="prof-whatsapp" type="tel"
            value="${h(teacher.whatsapp ?? '')}"
            placeholder="(11) 99999-9999">
        </div>
        <div class="fld">
          <label class="lbl">Celular</label>
          <input class="inp" id="prof-celular" type="tel"
            value="${h(teacher.celular ?? '')}"
            placeholder="(11) 99999-9999">
        </div>
      </div>
    </div>

    <div style="display:flex;gap:8px">
      <button class="btn btn-dark" style="flex:1" id="btn-save-profile"
        data-id="${teacher.id}">Salvar</button>
      <button class="btn btn-ghost"
        onclick="document.getElementById('overlay').classList.remove('on')">
        Cancelar
      </button>
    </div>`);

  document.getElementById('btn-save-profile')?.addEventListener('click', () => {
    saveProfile(teacher.id);
  });
}

async function saveProfile(teacherId) {
  const name     = document.getElementById('prof-name')?.value?.trim();
  const email    = document.getElementById('prof-email')?.value?.trim()    ?? '';
  const whatsapp = document.getElementById('prof-whatsapp')?.value?.trim() ?? '';
  const celular  = document.getElementById('prof-celular')?.value?.trim()  ?? '';

  if (!name) { document.getElementById('prof-name')?.focus(); return; }

  const teacher = state.teachers.find(t => t.id === teacherId);
  if (!teacher) return;

  teacher.name     = name;
  teacher.email    = email;
  teacher.whatsapp = whatsapp;
  teacher.celular  = celular;

  // Persiste localmente e no Firestore
  saveState();
  await saveDoc('teachers', teacher);

  close();
  // Atualiza a lista se estiver na aba de professores
  renderSettings?.();
}
